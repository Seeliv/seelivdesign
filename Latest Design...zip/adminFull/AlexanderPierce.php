<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Untitled Document</title>
<?php include("head.php") ?>
</head>

<body>
<?php include("headerMail.php"); ?>
<main>
<section class="side-bar">
  <div class="side-bar-content">
    <div class="search-list-item">
      <input type="text" placeholder="Search here">
      <div class="mail-option">
      <div class="optn-list">
                  <ul>
                    <li><a href=""><i class="fa fa-check-square" aria-hidden="true"></i></a></li>
                     <li><a href=""><i class="fa fa-trash" aria-hidden="true"></i></a></li>
                     <li><a href=""><i class="fa fa-reply"></i></a></li>
                     <li><a href=""><i class="fa fa-share"></i></a></li>
                     <li><a href=""><i class="fa fa-repeat" aria-hidden="true"></i></a></li>
                  </ul>
      </div>
      <div class="mail-count">
                        <span><strong>UnRead</strong> : 18</span>
                        <span><strong>All</strong> : 522</span> 
      </div>
    </div>
    </div>
    <div class="sidebar-list">
    
    <ul class="mail-list">
    
                                <li>
                                  <input type="checkbox" />
                                  <a href="#">Alexander Pierce</a>
                                  <p>AdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTE </p>  
                                </li>
                                <li>
                                  <input type="checkbox" />
                                  <a href="#">Alexander Pierce</a>
                                  <p>AdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTE </p>  
                                </li>
                                <li>
                                  <input type="checkbox" />
                                  <a href="#">Alexander Pierce</a>
                                  <p>AdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTE </p>  
                                </li>
                                <li>
                                  <input type="checkbox" />
                                  <a href="#">Alexander Pierce</a>
                                  <p>AdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTE </p>  
                                </li>
                                <li>
                                  <input type="checkbox" />
                                  <a href="#">Alexander Pierce</a>
                                  <p>AdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTE </p>  
                                </li>
                                <li>
                                  <input type="checkbox" />
                                  <a href="#">Alexander Pierce</a>
                                  <p>AdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTE </p>  
                                </li>
                                <li>
                                  <input type="checkbox" />
                                  <a href="#">Alexander Pierce</a>
                                  <p>AdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTE </p>  
                                </li>
                                <li>
                                  <input type="checkbox" />
                                  <a href="#">Alexander Pierce</a>
                                  <p>AdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTE </p>  
                                </li>
                                <li>
                                  <input type="checkbox" />
                                  <a href="#">Alexander Pierce</a>
                                  <p>AdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTE </p>  
                                </li>
                                <li>
                                  <input type="checkbox" />
                                  <a href="#">Alexander Pierce</a>
                                  <p>AdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTE </p>  
                                </li>
                                <li>
                                  <input type="checkbox" />
                                  <a href="#">Alexander Pierce</a>
                                  <p>AdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTEAdminLTE 3.0 Issue AdminLTE </p>  
                                </li>
                          </ul>
                          </div>
  </div>
</section>
<div class="content">
  <div class="content-data">
  <div class="content-in">
    <div class="content-fix-head"><h1>Alexander Pierce</h1>
      <div class="usr-mail-tool">
        <ul>
          <li><a title="Delete" href="#"><i class="fa fa-trash"></i></a></li>
          <li><a title="Reply" href="#"><i class="fa fa-reply"></i></a></li>
          <li><a title="Forward" href="#"><i class="fa fa-mail-forward"></i></a></li>
          <li><a title="Refresh" href="#"><i class="fa fa-repeat"></i></a></li>
        </ul>
      </div>
    </div>
    <div class="main-content">
      <div class="mail-read">
        <div class="mail-head">
          <h4>Message Subject Is Placed Here</h4>
          <p>Form:support@Adminlte.Io</p>
          <span class="mail-date">08-Mar-2011</span>
        </div>
        <div class="mail-body">
          <pre>
            Hello John,
            
            Keffiyeh blog actually fashion axe vegan, irony biodiesel. Cold-pressed hoodie chillwave put a bird on it aesthetic, 
            bitters brunch meggings vegan iPhone. Dreamcatcher vegan scenester mlkshk. Ethical master cleanse Bushwick, occupy Thundercats 
            banjo cliche ennui farm-to-table mlkshk fanny pack gluten-free. Marfa butcher vegan quinoa, bicycle rights disrupt tofu scenester 
            chillwave 3 wolf moon asymmetrical taxidermy pour-over. Quinoa tote bag fashion axe, Godard disrupt migas 
            church-key tofu blog locavore. Thundercats cronut polaroid Neutra tousled, meh food truck selfies narwhal American Apparel.

            Raw denim McSweeney's bicycle rights, iPhone trust fund quinoa Neutra VHS kale chips vegan PBR&B literally Thundercats +1. 
            Forage tilde four dollar toast, banjo health goth paleo butcher. Four dollar toast Brooklyn pour-over American Apparel sustainable, 
            lumbersexual listicle gluten-free health goth umami hoodie. Synth Echo Park bicycle rights DIY farm-to-table, retro kogi sriracha 
            dreamcatcher PBR&B flannel hashtag irony Wes Anderson. Lumbersexual Williamsburg Helvetica next level. Cold-pressed slow-carb popup
            normcore Thundercats Portland, cardigan literally meditation lumbersexual crucifix
          </pre>
        </div>
        <div class="mail-foot">
          <p><strong>3 Attachments</strong> <a href="#">Download</a></p>
          <ul class="mail-attach-files">
            <li><a href="#"><i class="fa fa-image"></i></a></li>
            <li><a href="#"><i class="fa fa-image"></i></a></li>
            <li><a href="#"><img src="images/side2.png" /></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
</main>
<?php include("footer.php"); ?>
</body>
</html>