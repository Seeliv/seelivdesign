<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Untitled Document</title>
<?php include("head.php") ?>
</head>

<body>
<?php include("header.php"); ?>
<main>
  <section class="side-bar">
    <div class="side-bar-content">
      <div class="search-list-item">
        <input type="text" placeholder="Search here">
      </div>
      <div class="sidebar-list">
        <ul class="fa-ul">
          <li><a href="#"><span class="fa-li"><img src="images/icon33.png"/></span>India</a></li>
          <li><a href="#"><span class="fa-li"><img src="images/icon32.png"/></span>Pakistan</a></li>
        </ul>
      </div>
    </div>
  </section>
  <div class="content">
    <div class="content-data">
      <div class="content-in">
        <div class="content-fix-head">
          <h1>Pakistan</h1>
        </div>
        <div class="main-content">
          <div class="setting-table">
           <div class="charge-table country-charge">
            <div class="table-part">
              <div class="part-heading">
                <span>Wallet Charges</span>	
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li><a href="" class="edit-btn"><img src="images/edit.png" class="iconback2"></a></li>
                    </ul>
                  </div>
                </div> 
              </div>
              <div class="part-row">
                <div class="part-heading">Top-up Charges</div>
                <div>0.00%</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Withdraw Charges</div>
                <div>0.00%</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              
            </div>
            <div class="table-part">
              <div class="part-heading">
                <span>Money Transfer Charges</span>	
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li><a href="" class="edit-btn"><img src="images/edit.png" class="iconback2"></a></li>
                    </ul>
                  </div>
                </div> 
              </div>
              <div class="part-row">
                <div class="part-heading">Charges Winin Border</div>
                <div>0.005 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Charges Out off Border</div>
                <div>0.005 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              
            </div>
            <div class="table-part">
              <div class="part-heading">
                <span>Ap Group Creation Charges</span>	
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li><a href="" class="edit-btn"><img src="images/edit.png" class="iconback2"></a></li>
                    </ul>
                  </div>
                </div> 
              </div>
              <div class="part-row">
                <div class="part-heading">For Students</div>
                <div>0.05 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>For Teachers</div>
                <div>0.05 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              
            </div>
            <div class="table-part">
              <div class="part-heading">
                <span>Session Management Charges</span>	
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li><a href="" class="edit-btn"><img src="images/edit.png" class="iconback2"></a></li>
                    </ul>
                  </div>
                </div> 
              </div>
              <div class="part-row">
                <div class="part-heading">Student Enrollment Charges</div>
                <div>15 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Online Attendance Charges</div>
                <div>0.02 USD / day</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Online Exams Charges</div>
                <div>0.02 USD / exams</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="table-part">
              <div class="part-heading">
                <span>Local Student's Fee Deduction </span>	
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li><a href="" class="edit-btn"><img src="images/edit.png" class="iconback2"></a></li>
                    </ul>
                  </div>
                </div> 
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison charges </div>
                <div>0.05 %= 1.50 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Guardian Charges </div>
                <div>1 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Coordinator Charges</div>
                <div>5 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Sub-Coordinator Charges </div>
                <div>1 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="table-part">
              <div class="part-heading">
                <span>Foreigner Student's Fee Deduction </span>	
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li><a href="" class="edit-btn"><img src="images/edit.png" class="iconback2"></a></li>
                    </ul>
                  </div>
                </div> 
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison charges </div>
                <div>0.05 %= 1.50 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Guardian Charges </div>
                <div>1 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Coordinator Charges</div>
                <div>5 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Sub-Coordinator Charges </div>
                <div>1 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="table-part">
              <div class="part-heading">
                <span>Local Teacher's Salary Deduction </span>	
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li><a href="" class="edit-btn"><img src="images/edit.png" class="iconback2"></a></li>
                    </ul>
                  </div>
                </div> 
              </div>
              <div class="part-row">
                <div class="part-heading">Intermediary Contract Liaison Charges </div>
                <div>0.05 % = 1.50 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Dispatching Contract Liaison Charges </div>
                <div>0.15 % = 3 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Guardian Charges</div>
                <div>10 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Coordinator Charges </div>
                <div>50 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Sub-Coordinator Charges </div>
                <div>10 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="table-part">
              <div class="part-heading">
                <span>Foreigner Teacher's Salary Deduction  </span>	
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li><a href="" class="edit-btn"><img src="images/edit.png" class="iconback2"></a></li>
                    </ul>
                  </div>
                </div> 
              </div>
              <div class="part-row">
                <div class="part-heading">Intermediary Contract Liaison Charges </div>
                <div>0.05 % = 1.50 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Dispatching Contract Liaison Charges </div>
                <div>0.15 % = 3 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Guardian Charges</div>
                <div>10 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Coordinator Charges </div>
                <div>50 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div>Sub-Coordinator Charges </div>
                <div>10 %</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="table-part">
              <div class="part-heading">
                <span>Local Teacher's Recruitment Charges </span>	
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li><a href="" class="edit-btn"><img src="images/edit.png" class="iconback2"></a></li>
                    </ul>
                  </div>
                </div> 
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Kindergarten ) </div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Training School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Primary school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Middle School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Secondary school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Junior Secondary School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Senior Secondary School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Vocational School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Post-secondary school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( High school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Junior high school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Senior high school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( College )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Tertiary School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( University )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Attendant Charges</div>
                <div>10 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Guardian Charges</div>
                <div>5 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Coordinator Charges</div>
                <div>5 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Sub-Coordinator Charges</div>
                <div>5 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="table-part">
              <div class="part-heading">
                <span>Foreigner Teacher's Recruitment Charges </span>	
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li><a href="" class="edit-btn"><img src="images/edit.png" class="iconback2"></a></li>
                    </ul>
                  </div>
                </div> 
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Kindergarten ) </div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Training School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Primary school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Middle School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Secondary school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Junior Secondary School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Senior Secondary School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Vocational School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Post-secondary school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( High school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Junior high school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Senior high school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( College )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Tertiary School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( University )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Attendant Charges</div>
                <div>10 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Guardian Charges</div>
                <div>5 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Coordinator Charges</div>
                <div>5 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Sub-Coordinator Charges</div>
                <div>5 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="table-part">
              <div class="part-heading">
                <span>Teacher Value Charges As A Foreigner </span>	
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li><a href="" class="edit-btn"><img src="images/edit.png" class="iconback2"></a></li>
                    </ul>
                  </div>
                </div> 
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Kindergarten ) </div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Training School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Primary school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Middle School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Secondary school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Junior Secondary School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Senior Secondary School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Vocational School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Post-secondary school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( High school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Junior high school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Senior high school )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( College )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( Tertiary School )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Liaison Charges ( University )</div>
                <div>20 USD = 300</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Attendant Charges</div>
                <div>10 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Guardian Charges</div>
                <div>5 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Coordinator Charges</div>
                <div>5 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="part-row">
                <div class="part-heading">Sub-Coordinator Charges</div>
                <div>5 USD</div>
                <div class="set-action">
                  <div class="sidebtn ">
                    <ul>
                      <li> <a href="">
                        <label class="switch">
                          <input type="checkbox">
                          <span class="slider round"></span> </label>
                        </a> </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
           </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>
<?php include("footer.php"); ?>
</body>
</html>