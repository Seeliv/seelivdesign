<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Untitled Document</title>
<?php include("head.php") ?>
</head>

<body >
<div class="top-log">
  <div class="lang"><a href="#">English</a><a href="#">Hindi</a> </div>
  <div class="log-pg-hds">Reset Password</div>
  <div class="log-pg-optn"><a href="#"><i class="fa fa-question"></i><strong>Support</strong></a></div>
</div>
<div class="general-form">
  <div class="form-field">
  <input type="text" placeholder="Type 6 digit New ASP PIN" />
  </div>
  <div class="form-field">
  <input type="text" placeholder="Retype 6 digit New ASP PIN" />
  </div>
  <div class="form-field">
    <input type="button" value="Update ASP PIN" class="roll-btn full-btn" />
  </div>
  <p><a href="#" >Return To Login</a></p>
</div>
<?php include("footer.php"); ?>
</body>
</html>