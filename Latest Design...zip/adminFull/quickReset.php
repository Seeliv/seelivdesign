<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Untitled Document</title>
<?php include("head.php") ?>
</head>

<body >
<div class="top-log">
  <div class="lang"><a href="#">English</a><a href="#">Hindi</a> </div>
  <div class="log-pg-hds">Quick Reset Password</div>
  <div class="log-pg-optn"><a href="#"><i class="fa fa-question"></i><strong>Support</strong></a></div>
</div>
<div class="general-form">
  <p class="sim-pera">Are you Sure to Change Your Account Password ?</p>
  <div class="form-field">
  <input type="text" placeholder="Type New Password" />
  </div>
  <div class="form-field">
  <input type="text" placeholder="Retype New Password" />
  </div>
  <div class="form-field">
    <input type="button" value="Update Password" class="roll-btn full-btn" />
  </div>
  <p><a href="#" >Return To Login</a></p>
</div>
<?php include("footer.php"); ?>
</body>
</html>