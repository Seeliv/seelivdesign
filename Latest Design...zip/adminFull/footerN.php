<footer>
<script src="js/jquery.min.js"></script>
<script src="js/custum.js"></script>
<script src="js/jquery.mousewheel.min.js"></script>
<script src="js/scrollbar.js"></script>
<script src="js/forScroll.js">  </script>  
</footer>