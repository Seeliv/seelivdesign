<footer>
<script src="js/jquery.min.js"></script>
<script src="js/custum.js"></script>
</footer>